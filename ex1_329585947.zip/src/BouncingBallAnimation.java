import biuoop.DrawSurface;
import biuoop.GUI;
import java.lang.Math;
public class BouncingBallAnimation {


    static private void drawAnimation(Point start, double dx, double dy) {
        GUI gui = new GUI("title",200,200);
        biuoop.Sleeper sleeper = new biuoop.Sleeper();
        //Sleeper sleeper = new Sleeper();
        //Point pStart = new Point(start.getX(), start.getY());
        Ball ball = new Ball(start, 30, java.awt.Color.BLACK);
        ball.setVelocity(dx, dy);
        while (true) {
            ball.moveOneStep(200,200, 0, 0);
            DrawSurface d = gui.getDrawSurface();
            ball.drawOn(d);
            gui.show(d);
            sleeper.sleepFor(50);  // wait for 50 milliseconds.
        }
    }


    public static void main(String[] args){
        if (args.length>0){
            Point center = new Point(Integer.parseInt(args[0]),Integer.parseInt(args[1]));
            int dx = Integer.parseInt(args[2]);
            int dy = Integer.parseInt(args[3]);

            drawAnimation(center,dx,dy);
        }
    }
}
