public class Line {

    private Point start;
    private Point end;
    private double slope;

    // constructors
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
        this.slope = (this.start.getY() - this.end.getY()) / (this.start.getX() - this.end.getX());
    }

    public Line(double x1, double y1, double x2, double y2) {
        Point p_start = new Point(x1, y1);
        Point p_end = new Point(x2, y2);
        this.start = p_start;
        this.end = p_end;
    }

    // Return the length of the line
    public double length() {
        return this.start.distance(this.end);
    }

    // Returns the middle point of the line
    public Point middle() {
        Point middle = new Point((this.start.getX() + this.end.getX()) / 2, (this.start.getY() + this.end.getY()) / 2);
        return middle;
    }

    // Returns the start point of the line
    public Point start() {
        return this.start;
    }

    // Returns the end point of the line
    public Point end() {
        return this.end;
    }

    // finds the equation of a line(helper method to the isIntersecting method)
    public double yIntersection() {
        return this.start.getY() - this.slope * this.start.getX();
    }


    // Returns true if the lines intersect, false otherwise
    // The doubles represent a way to fine an intersection point, to solve an equation.
    // The last "if" is to confirm that the lines contain the intersection point.
    public boolean isIntersecting(Line other) {
        if (this.slope != other.slope) {
            double minusSlope = this.slope - other.slope;
            double minusY_intersect = other.yIntersection() - this.yIntersection();
            double intersect_x_point = minusY_intersect / minusSlope;
            double intersect_y_point = this.slope * intersect_x_point + this.yIntersection();
            Point intersectPoint = new Point(intersect_x_point, intersect_y_point);
            if (intersectPoint.getX() > this.start.getX() && intersectPoint.getX() > other.start.getX() && intersectPoint.getX() < this.end.getX() && intersectPoint.getX() < other.end.getX()) {
                return true;
            }

        }
        return false;
    }

    // Returns the intersection point if the lines intersect,
    // and null otherwise.
    public Point intersectionWith(Line other) {
        if (this.isIntersecting(other)) {
            double minusSlope = this.slope - other.slope;
            double minusY_intersect = other.yIntersection() - this.yIntersection();
            double intersect_x_point = minusY_intersect / minusSlope;
            double intersect_y_point = this.slope * intersect_x_point + this.yIntersection();
            Point intersectPoint = new Point(intersect_x_point, intersect_y_point);
            return intersectPoint;
        }
        return null;
    }

    // equals -- return true is the lines are equal, false otherwise
    public boolean equals(Line other) {
        return this.start.equals(other.start) && this.end.equals(other.end);
    }
}

