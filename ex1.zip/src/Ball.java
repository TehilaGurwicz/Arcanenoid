import java.lang.Math;
import biuoop.DrawSurface;
import biuoop.GUI;
import java.awt.Color;


public class Ball {
    private Point center;
    private double r;
    private java.awt.Color color;
    private Velocity velocity;
    private Point point;


    // constructor
    public Ball(Point center, int r, java.awt.Color color){
        this.center = center;
        this.r = r;
        this.color = color;
    }



    // accessors
    public int getX() {return (int) this.center.getX();}
    public int getY() {return (int) this.center.getY();}
    public int getR() {return (int) this.r;}
    public int getSize() {return (int) (Math.PI*r*r);}

    public java.awt.Color getColor() {return this.color;}

    // draw the ball on the given DrawSurface
    public void drawOn(DrawSurface surface){
        surface.setColor(this.color);
        surface.fillCircle((int) this.center.getX(), (int) this.center.getY(),(int) r);
    }


    public void setVelocity(Velocity v) {this.velocity = v;}
    public void setVelocity(double dx, double dy) {
        this.velocity= new Velocity(dx,dy);
    }


    public Velocity getVelocity() {
        return new Velocity (this.velocity.getDx(), this.velocity.getDy());
    }

// moves the ball by adding dx/y to the center and prevent the ball from going out of the borders
    public void moveOneStep(int heightG, int widthG, int down, int start){
        if(this.center.getY() + getVelocity().getDy() + this.r > heightG ) {setVelocity(this.velocity.getDx(),-this.velocity.getDy());}
        if(this.center.getY() + getVelocity().getDy() - this.r < down) {setVelocity(this.velocity.getDx(),-this.velocity.getDy());}
        if(this.center.getX() + getVelocity().getDx() + this.r > widthG) {setVelocity(-this.velocity.getDx(),this.velocity.getDy());}
        if(this.center.getX() + getVelocity().getDx() - this.r < start) {setVelocity(-this.velocity.getDx(),this.velocity.getDy());}
        this.center = this.getVelocity().applyToPoint(this.center);

    }
}
