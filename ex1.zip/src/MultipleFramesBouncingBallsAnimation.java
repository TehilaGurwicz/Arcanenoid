import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

import javax.print.attribute.standard.PrinterMakeAndModel;
import java.util.Random;
import java.awt.Color;


public class MultipleFramesBouncingBallsAnimation {

    public static boolean limitSize(int height_width, int r){
        if (2*r >= height_width){
            System.out.println("Radius too long, giv a number smaller than" + height_width);
            return false;
        }
        {return true;}
    }


    /*It might seems long and complicated but it's the same algorithm from MultiBouncingBallsAnimation, DrawSurface*/
    public static void multiFrames(Ball[] balls){
        Random rand = new Random();
        GUI gui = new GUI( "title", 700, 700);
        Sleeper sleeper = new Sleeper();

        for(int i = 0; i < balls.length; i++){
            balls[i].setVelocity(Velocity.fromAngleAndSpeed(rand.nextInt(360),(double) 50 /balls[i].getR()));
        }

        int middleS = (int) (balls.length/2);
        while (true) {

            DrawSurface d = gui.getDrawSurface();

            Frame f1 = new Frame(new Point(50,50),450,450, java.awt.Color.GRAY);
            f1.drawFrame(d);

            Frame f2 = new Frame(new Point(450,450),150,150, java.awt.Color.YELLOW);
            f2.drawFrame(d);


            for(int i = 0; i < middleS; i++ ){
                balls[i].moveOneStep( 600,600 , 450, 450);
                balls[i].drawOn(d);

            }

            for(int i = middleS; i < balls.length; i++ ){
                balls[i].moveOneStep( 500,500 , 50, 50);
                balls[i].drawOn(d);

            }
            sleeper.sleepFor(50);
            gui.show(d);

        }
    }

    public static void main(String[] args){
        Random rand = new Random();


        Ball[] balls = new Ball[args.length];
        int count1 = 0;
        int count2 = (int) (balls.length / 2);


        /*puts all the balls in the array and making sure the ball starts completely inside of the surface by reducing
        the size of the surface depends on the r size.
        */
        for (int i = 0; i < (int) balls.length/2; i++){
            if (limitSize(150,Integer.parseInt(args[count1]))) {
                int r = Integer.parseInt(args[count1]);
                balls[i] = new Ball(new Point(rand.nextInt(150-2*r) +450+r, rand.nextInt(150-2*r) +450+r),r, MultipleBouncingBallsAnimation.getRandomColor());
                count1++;}

        }

        for (int i =(int) balls.length/2; i < balls.length; i++){
            if (limitSize(450,Integer.parseInt(args[count1]))) {
                int r = Integer.parseInt(args[count2]);
                balls[i] = new Ball(new Point(rand.nextInt(450-2*r)+ 50+r, rand.nextInt(450-2*r)+50+r),r, MultipleBouncingBallsAnimation.getRandomColor());
                count2++;
            }
        }

        multiFrames(balls);

    }


}
