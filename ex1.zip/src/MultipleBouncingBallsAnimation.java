import biuoop.GUI;
import biuoop.DrawSurface;
import biuoop.Sleeper;

import javax.print.attribute.standard.PrinterMakeAndModel;
import java.util.Random;
import java.awt.Color;


public class MultipleBouncingBallsAnimation {

    /*choosing a random color method*/
    public static Color getRandomColor() {
        Random rand = new Random();
        int r = rand.nextInt(256); // 0–255
        int g = rand.nextInt(256);
        int b = rand.nextInt(256);
        return new Color(r, g, b);
    }

//    public static void multiBounce(Ball[] balls){
//        int ballSpeed =
//
//    }


    static private void drawAnimation(Ball[] balls){
        Random rand = new Random();
        GUI gui = new GUI("title",200,200);
        Sleeper sleeper = new Sleeper();
        for(int i = 0; i < balls.length; i++){
            balls[i].setVelocity(Velocity.fromAngleAndSpeed(rand.nextInt(360),(double) 50 /balls[i].getR()));
        }
        while (true) {
            DrawSurface d = gui.getDrawSurface();
            for(int i = 0; i < balls.length; i++ ){
                balls[i].moveOneStep(200,200 , 0, 0);
                balls[i].drawOn(d);
            }
            gui.show(d);
            sleeper.sleepFor(50);
        }
        
    }


    public static void main(String[] args){
        Random rand = new Random();

        int count = 0;
        Ball[] balls = new Ball[args.length];


        /*puts all the balls in the array and making sure the ball starts completely inside of the surface by reducing
        the size of the surface depends on the r size.
        */
        for (int i = 0; i < balls.length; i++){
            int r = Integer.parseInt(args[count]);
            balls[i] = new Ball(new Point(rand.nextInt(200-2*r)+r, rand.nextInt(200 -2*r)+r),r, getRandomColor());
            count++;
        }

        drawAnimation(balls);

    }
}
